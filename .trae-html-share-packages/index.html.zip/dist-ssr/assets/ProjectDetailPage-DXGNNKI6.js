import { jsx, jsxs } from "react/jsx-runtime";
import { useParams, Navigate, Link } from "react-router-dom";
import { f as findProject, p as projectPrevNext, a as allProjects, A as ArrowLeftIcon, E as ExternalLink } from "../entry-server.js";
import { g as getProjectBody, M as MarkdownBody } from "./store-bodies-CzwW5kKy.js";
import "node:stream";
import "react-dom/server";
import "react-router-dom/server.mjs";
import "react";
import "zod";
const head = "_head_398h1_1";
const back = "_back_398h1_5";
const title = "_title_398h1_14";
const summary = "_summary_398h1_20";
const meta = "_meta_398h1_26";
const links = "_links_398h1_35";
const overview = "_overview_398h1_41";
const overviewItem = "_overviewItem_398h1_54";
const overviewLabel = "_overviewLabel_398h1_61";
const overviewText = "_overviewText_398h1_68";
const prevNext = "_prevNext_398h1_74";
const footerCta = "_footerCta_398h1_84";
const footerText = "_footerText_398h1_97";
const styles = {
  head,
  back,
  title,
  summary,
  meta,
  links,
  overview,
  overviewItem,
  overviewLabel,
  overviewText,
  prevNext,
  footerCta,
  footerText
};
function ProjectDetailPage() {
  const { slug } = useParams();
  const project = slug ? findProject(allProjects, slug) : void 0;
  const body = project ? getProjectBody(project.slug) : void 0;
  if (!project || !body) {
    return /* @__PURE__ */ jsx(Navigate, { to: "/404", replace: true });
  }
  const { prev, next } = projectPrevNext(allProjects, project.slug);
  return /* @__PURE__ */ jsx("div", { className: "container section", children: /* @__PURE__ */ jsxs("div", { style: { maxWidth: "var(--prose)" }, children: [
    /* @__PURE__ */ jsxs("header", { className: styles.head, children: [
      /* @__PURE__ */ jsxs(Link, { to: "/projects", className: styles.back, children: [
        /* @__PURE__ */ jsx(ArrowLeftIcon, {}),
        " 返回项目列表"
      ] }),
      /* @__PURE__ */ jsx("h1", { className: styles.title, children: project.title }),
      /* @__PURE__ */ jsx("p", { className: styles.summary, children: project.summary }),
      /* @__PURE__ */ jsxs("div", { className: styles.meta, children: [
        /* @__PURE__ */ jsx("span", { children: project.period }),
        /* @__PURE__ */ jsx("span", { children: project.role }),
        project.teamSize && /* @__PURE__ */ jsxs("span", { children: [
          "团队 ",
          project.teamSize,
          " 人"
        ] }),
        /* @__PURE__ */ jsx("span", { children: project.stack.join(" / ") })
      ] }),
      project.links.length > 0 && /* @__PURE__ */ jsx("div", { className: styles.links, children: project.links.map((link) => /* @__PURE__ */ jsx(ExternalLink, { href: link.href, children: link.label }, link.href)) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: styles.overview, children: [
      /* @__PURE__ */ jsxs("div", { className: styles.overviewItem, children: [
        /* @__PURE__ */ jsx("h2", { className: styles.overviewLabel, children: "问题" }),
        /* @__PURE__ */ jsx("p", { className: styles.overviewText, children: project.overview.problem })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: styles.overviewItem, children: [
        /* @__PURE__ */ jsx("h2", { className: styles.overviewLabel, children: "目标" }),
        /* @__PURE__ */ jsx("p", { className: styles.overviewText, children: project.overview.goal })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: styles.overviewItem, children: [
        /* @__PURE__ */ jsx("h2", { className: styles.overviewLabel, children: "结果" }),
        /* @__PURE__ */ jsx("p", { className: styles.overviewText, children: project.overview.result })
      ] })
    ] }),
    /* @__PURE__ */ jsx(MarkdownBody, { html: body.bodyHtml }),
    /* @__PURE__ */ jsxs("nav", { className: styles.prevNext, "aria-label": "项目导航", children: [
      /* @__PURE__ */ jsx("span", { children: prev && /* @__PURE__ */ jsxs(Link, { to: prev.href, children: [
        "← ",
        prev.title
      ] }) }),
      /* @__PURE__ */ jsx("span", { children: next && /* @__PURE__ */ jsxs(Link, { to: next.href, children: [
        next.title,
        " →"
      ] }) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: styles.footerCta, children: [
      /* @__PURE__ */ jsx("p", { className: styles.footerText, children: "对这个项目有疑问，或想聊聊类似的问题？" }),
      /* @__PURE__ */ jsx(Link, { to: "/#contact", className: "btn btnPrimary", children: "联系我" })
    ] })
  ] }) });
}
export {
  ProjectDetailPage as default
};
