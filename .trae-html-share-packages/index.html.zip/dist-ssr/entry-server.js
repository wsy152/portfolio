import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { Writable } from "node:stream";
import { renderToPipeableStream } from "react-dom/server";
import { StaticRouter } from "react-router-dom/server.mjs";
import { useEffect, useState, useRef, useCallback, lazy, Suspense } from "react";
import { useLocation, Link, NavLink, Outlet, useSearchParams, Route, Routes } from "react-router-dom";
import { z } from "zod";
const dateString = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "日期必须是 YYYY-MM-DD");
const projectLinkSchema = z.object({
  label: z.string().min(1),
  href: z.string().url(),
  kind: z.enum(["live", "repo", "doc"])
});
z.object({
  title: z.string().min(1).max(40),
  slug: z.string().regex(/^[a-z0-9-]+$/),
  summary: z.string().min(10).max(80),
  role: z.string().min(1),
  teamSize: z.number().int().positive().optional(),
  startDate: dateString,
  endDate: dateString.optional(),
  stack: z.array(z.string()).min(1),
  cover: z.string().optional(),
  links: z.array(projectLinkSchema).default([]),
  overview: z.object({
    problem: z.string().min(20),
    goal: z.string().min(10),
    result: z.string().min(10)
  }),
  featured: z.boolean().default(false),
  order: z.number().int().default(0),
  draft: z.boolean().default(false)
});
z.object({
  title: z.string().min(1).max(60),
  slug: z.string().regex(/^[a-z0-9-]+$/),
  date: dateString,
  updated: dateString.optional(),
  summary: z.string().max(120).optional(),
  cover: z.string().optional(),
  tags: z.array(z.string()).max(5).default([]),
  draft: z.boolean().default(false)
});
const siteConfigSchema = z.object({
  name: z.string(),
  role: z.string(),
  tagline: z.string().max(30),
  location: z.string(),
  availability: z.string().optional(),
  email: z.string().email(),
  avatar: z.string().optional(),
  resumeUrl: z.string(),
  social: z.array(z.object({ label: z.string(), href: z.string().url() }))
});
const site = siteConfigSchema.parse({
  name: "张示例",
  role: "前端工程师",
  tagline: "做前端基础设施的工程师",
  location: "上海",
  availability: "在职，考虑机会",
  email: "hello@example.com",
  resumeUrl: "/resume-2026-10.pdf",
  social: [
    { label: "GitHub", href: "https://github.com/example" },
    { label: "掘金", href: "https://juejin.cn/user/example" }
  ]
});
const experiences = [
  {
    company: "示例科技有限公司",
    title: "高级前端工程师",
    period: "2023.06 – 至今",
    current: true,
    outcome: "主导前端基础设施升级，构建耗时降低 60%。"
  },
  {
    company: "示例网络公司",
    title: "前端工程师",
    period: "2020.07 – 2023.05",
    current: false,
    outcome: "负责核心业务前端，支撑日活百万级页面。"
  }
];
const education = [
  {
    school: "示例大学",
    major: "计算机科学与技术 · 本科",
    period: "2016 – 2020"
  }
];
const currentFocus = [
  "在维护本站点，并把工作中的工程实践整理成文章。",
  "关注构建性能与 Web 无障碍方向。"
];
const rawContent = { "projects": [{ "title": "示例 · 指标监控平台", "slug": "metrics-platform", "summary": "示例项目：把 12 个分散的监控页面收拢成一个可下钻的统一工作台。", "role": "前端负责人", "teamSize": 6, "startDate": "2025-03-01", "endDate": "2025-11-30", "stack": ["React", "TypeScript", "WebSocket"], "links": [{ "label": "在线演示", "href": "https://example.com", "kind": "live" }], "overview": { "problem": "示例内容：业务方需要跨 12 个页面手工对比指标，一次排障要在多个页面间反复切换。", "goal": "示例内容：在一个页面内完成指标聚合、下钻与告警确认，减少页面切换。", "result": "示例内容：上线后排障流程收拢到单页面完成，切换次数显著下降（数据为脱敏示例）。" }, "featured": true, "order": 1, "draft": false, "href": "/projects/metrics-platform", "period": "2025.03 – 2025.11", "updatedAt": "2025-11-30" }, { "title": "示例 · 组件设计系统", "slug": "design-system", "summary": "示例项目：为三条业务线统一组件与设计 token，减少重复实现。", "role": "核心贡献者", "teamSize": 4, "startDate": "2024-05-01", "endDate": "2025-02-28", "stack": ["React", "CSS", "Figma"], "links": [{ "label": "源码", "href": "https://github.com/example/design-system", "kind": "repo" }], "overview": { "problem": "示例内容：三条业务线各自维护组件，同一按钮有五种实现，视觉与交互不一致。", "goal": "示例内容：建立统一 token 与组件库，让新页面默认走设计系统。", "result": "示例内容：组件库覆盖主要业务场景，重复实现基本消除（数据为脱敏示例）。" }, "featured": true, "order": 2, "draft": false, "href": "/projects/design-system", "period": "2024.05 – 2025.02", "updatedAt": "2025-02-28" }, { "title": "示例 · 草稿项目", "slug": "draft-example", "summary": "示例草稿：这篇内容不会出现在列表与线上产物中。", "role": "示例", "startDate": "2026-06-01", "stack": ["React"], "links": [], "overview": { "problem": "示例内容：这是草稿，仅本地预览可见，不进入线上产物。", "goal": "示例内容：验证草稿过滤逻辑。", "result": "示例内容：构建产物中不应出现该页面。" }, "featured": false, "order": 0, "draft": true, "href": "/projects/draft-example", "period": "2026.06 – 至今", "updatedAt": "9999-12-31" }, { "title": "示例 · 构建缓存优化", "slug": "build-cache", "summary": "示例项目：把 CI 构建时间从 18 分钟降到 4 分钟的缓存分层实践。", "role": "独立负责", "startDate": "2026-01-15", "stack": ["Vite", "GitHub Actions"], "links": [], "overview": { "problem": "示例内容：CI 全量构建每次 18 分钟，前端迭代被构建队列阻塞。", "goal": "示例内容：通过依赖缓存与产物分层，把常规提交构建控制在 5 分钟内。", "result": "示例内容：常规构建降至 4 分钟，团队反馈迭代节奏明显改善（数据为脱敏示例）。" }, "featured": false, "order": 3, "draft": false, "href": "/projects/build-cache", "period": "2026.01 – 至今", "updatedAt": "9999-12-31" }], "posts": [{ "title": "示例 · 我是怎么给这个站点做静态生成的", "slug": "how-this-site-is-built", "date": "2026-09-12", "summary": "示例文章：记录本站从 Markdown 到静态 HTML 的构建链路设计。", "tags": ["Vite", "静态站点"], "draft": false, "displayDate": "9月12日", "readingMinutes": 2, "href": "/blog/how-this-site-is-built", "year": "2026" }, { "title": "示例 · 预渲染时的三个坑", "slug": "prerender-pitfalls", "date": "2026-07-03", "tags": ["React", "SSR"], "draft": false, "summary": "本文是示例内容，用于演示「无摘要时自动截取正文」的列表样式。 渲染期访问浏览器 API 示例内容：预渲染在 Node 中执行，任何 、 访问都会抛错，必须放进 。 Hydration 不一致 示例内容： 、 这类不确定值会让两端渲染结果不同…", "displayDate": "7月3日", "readingMinutes": 1, "href": "/blog/prerender-pitfalls", "year": "2026" }, { "title": "示例 · 一次构建缓存排查记录", "slug": "cache-debug-notes", "date": "2025-11-20", "tags": ["构建"], "draft": false, "summary": "本文是示例内容，用于演示跨年分组（2025 年）。 现象 示例内容：CI 缓存命中率突然归零，构建耗时翻倍。 定位过程 示例内容：先对比两次构建的 cache key，再检查 lock 文件是否有非预期变更。 结论 示例内容：一次依赖升级改…", "displayDate": "2025年11月20日", "readingMinutes": 1, "href": "/blog/cache-debug-notes", "year": "2025" }] };
function publishedProjects(projects, includeDrafts) {
  return projects.filter((p) => !p.draft);
}
function publishedPosts(posts, includeDrafts) {
  return posts.filter((p) => !p.draft);
}
function featuredProjects(projects, count2 = 3) {
  return projects.slice(0, count2);
}
function latestPosts(posts, count2 = 3) {
  return posts.slice(0, count2);
}
function findProject(projects, slug) {
  return projects.find((p) => p.slug === slug);
}
function findPost(posts, slug) {
  return posts.find((p) => p.slug === slug);
}
function projectPrevNext(projects, slug) {
  const index = projects.findIndex((p) => p.slug === slug);
  if (index < 0) {
    return {};
  }
  return { prev: projects[index - 1], next: projects[index + 1] };
}
function postPrevNext(posts, slug) {
  const index = posts.findIndex((p) => p.slug === slug);
  if (index < 0) {
    return {};
  }
  return { prev: posts[index - 1], next: posts[index + 1] };
}
function groupPostsByYear(posts) {
  const groups = [];
  for (const post of posts) {
    const last = groups[groups.length - 1];
    if (last && last.year === post.year) {
      last.posts.push(post);
    } else {
      groups.push({ year: post.year, posts: [post] });
    }
  }
  return groups;
}
function collectProjectTags(projects) {
  const counts = /* @__PURE__ */ new Map();
  for (const project of projects) {
    for (const tag2 of project.stack) {
      counts.set(tag2, (counts.get(tag2) ?? 0) + 1);
    }
  }
  return [...counts.entries()].map(([tag2, count2]) => ({ tag: tag2, count: count2 })).sort((a, b) => b.count - a.count || a.tag.localeCompare(b.tag));
}
function filterProjectsByTag(projects, tag2) {
  if (!tag2) {
    return projects;
  }
  return projects.filter((p) => p.stack.includes(tag2));
}
const data = rawContent;
const allProjects = publishedProjects(data.projects);
const allPosts = publishedPosts(data.posts);
const BASE_PATH = "/";
const SITE_URL = "https://example.com";
const DEFAULT_DESCRIPTION = `${site.name}的个人作品集：${site.tagline}。`;
function absoluteUrl(path) {
  const base = BASE_PATH.endsWith("/") ? BASE_PATH.slice(0, -1) : BASE_PATH;
  return `${SITE_URL}${base}${path}`;
}
function resolveMeta(pathname) {
  const notFound = {
    title: `页面不存在 · ${site.name}`,
    description: DEFAULT_DESCRIPTION,
    path: pathname,
    type: "website"
  };
  if (pathname === "/" || pathname === "") {
    return { title: `${site.name} · ${site.role}`, description: DEFAULT_DESCRIPTION, path: "/", type: "website" };
  }
  if (pathname === "/about") {
    return { title: `关于 · ${site.name}`, description: `${site.name}的完整介绍与经历。`, path: "/about", type: "website" };
  }
  if (pathname === "/projects") {
    return { title: `项目 · ${site.name}`, description: "项目列表：方向、角色与结果。", path: "/projects", type: "website" };
  }
  if (pathname === "/blog") {
    return { title: `博客 · ${site.name}`, description: "技术文章与工程实践记录。", path: "/blog", type: "website" };
  }
  const projectMatch = /^\/projects\/([a-z0-9-]+)$/.exec(pathname);
  if (projectMatch) {
    const project = findProject(allProjects, projectMatch[1]);
    if (!project) {
      return notFound;
    }
    return {
      title: `${project.title} · ${site.name}`,
      description: project.summary,
      path: project.href,
      type: "article",
      image: `/og/project-${project.slug}.png`
    };
  }
  const postMatch = /^\/blog\/([a-z0-9-]+)$/.exec(pathname);
  if (postMatch) {
    const post = findPost(allPosts, postMatch[1]);
    if (!post) {
      return notFound;
    }
    return {
      title: `${post.title} · ${site.name}`,
      description: post.summary,
      path: post.href,
      type: "article",
      image: `/og/post-${post.slug}.png`
    };
  }
  return notFound;
}
function escapeHtml(text2) {
  return text2.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function renderHead(meta2) {
  const canonical = absoluteUrl(meta2.path);
  const image = absoluteUrl(meta2.image ?? "/og/default.png");
  return [
    `<title>${escapeHtml(meta2.title)}</title>`,
    `<meta name="description" content="${escapeHtml(meta2.description)}" />`,
    `<link rel="canonical" href="${escapeHtml(canonical)}" />`,
    `<meta property="og:title" content="${escapeHtml(meta2.title)}" />`,
    `<meta property="og:description" content="${escapeHtml(meta2.description)}" />`,
    `<meta property="og:type" content="${meta2.type}" />`,
    `<meta property="og:url" content="${escapeHtml(canonical)}" />`,
    `<meta property="og:image" content="${escapeHtml(image)}" />`,
    `<meta name="twitter:card" content="summary_large_image" />`
  ].join("\n    ");
}
function Seo() {
  const location2 = useLocation();
  useEffect(() => {
    var _a;
    const meta2 = resolveMeta(location2.pathname);
    document.title = meta2.title;
    (_a = document.querySelector('meta[name="description"]')) == null ? void 0 : _a.setAttribute("content", meta2.description);
  }, [location2.pathname]);
  return null;
}
const wrapper = "_wrapper_wl1jn_1";
const button = "_button_wl1jn_7";
const toast = "_toast_wl1jn_18";
const styles$c = {
  wrapper,
  button,
  toast
};
const TOAST_DURATION = 2e3;
function CopyEmailButton({ className }) {
  const [toast2, setToast] = useState(null);
  const timerRef = useRef(null);
  const textRef = useRef(null);
  const showToast = useCallback((message) => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
    setToast(message);
    timerRef.current = setTimeout(() => setToast(null), TOAST_DURATION);
  }, []);
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, []);
  useEffect(() => {
    if (!toast2) {
      return;
    }
    const onKeyDown = (event) => {
      if (event.key === "Escape") {
        setToast(null);
      }
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [toast2]);
  const copy = useCallback(async () => {
    const email2 = site.email;
    try {
      await navigator.clipboard.writeText(email2);
      showToast("邮箱已复制");
      return;
    } catch {
    }
    try {
      const textarea = document.createElement("textarea");
      textarea.value = email2;
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.select();
      const ok = document.execCommand("copy");
      textarea.remove();
      showToast(ok ? "邮箱已复制" : "请手动复制");
      if (!ok) {
        selectEmailText();
      }
    } catch {
      showToast("请手动复制");
      selectEmailText();
    }
  }, [showToast]);
  const selectEmailText = () => {
    const node = textRef.current;
    if (!node) {
      return;
    }
    const range = document.createRange();
    range.selectNodeContents(node);
    const selection = window.getSelection();
    selection == null ? void 0 : selection.removeAllRanges();
    selection == null ? void 0 : selection.addRange(range);
  };
  return /* @__PURE__ */ jsxs("span", { className: styles$c.wrapper, children: [
    /* @__PURE__ */ jsx("button", { type: "button", className: `${styles$c.button} ${className ?? ""}`, onClick: copy, "aria-label": `复制邮箱 ${site.email}`, children: /* @__PURE__ */ jsx("span", { ref: textRef, children: site.email }) }),
    toast2 && /* @__PURE__ */ jsx("span", { className: styles$c.toast, role: "status", "aria-live": "polite", children: toast2 })
  ] });
}
function ExternalIcon({ size = 14 }) {
  return /* @__PURE__ */ jsx("svg", { width: size, height: size, viewBox: "0 0 16 16", fill: "none", "aria-hidden": "true", children: /* @__PURE__ */ jsx(
    "path",
    {
      d: "M6 3H3v10h10v-3M9 2h5v5M14 2 7.5 8.5",
      stroke: "currentColor",
      strokeWidth: "1.5",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }
  ) });
}
function MenuIcon({ size = 20 }) {
  return /* @__PURE__ */ jsx("svg", { width: size, height: size, viewBox: "0 0 20 20", fill: "none", "aria-hidden": "true", children: /* @__PURE__ */ jsx("path", { d: "M3 5h14M3 10h14M3 15h14", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round" }) });
}
function CloseIcon({ size = 20 }) {
  return /* @__PURE__ */ jsx("svg", { width: size, height: size, viewBox: "0 0 20 20", fill: "none", "aria-hidden": "true", children: /* @__PURE__ */ jsx("path", { d: "M5 5l10 10M15 5 5 15", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round" }) });
}
function ArrowLeftIcon({ size = 14 }) {
  return /* @__PURE__ */ jsx("svg", { width: size, height: size, viewBox: "0 0 16 16", fill: "none", "aria-hidden": "true", children: /* @__PURE__ */ jsx("path", { d: "M10 3 5 8l5 5", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round" }) });
}
function ExternalLink({ href, children, className, showIcon = true }) {
  return /* @__PURE__ */ jsxs("a", { href, target: "_blank", rel: "noopener noreferrer", className, children: [
    children,
    showIcon && /* @__PURE__ */ jsxs(Fragment, { children: [
      " ",
      /* @__PURE__ */ jsx(ExternalIcon, {}),
      /* @__PURE__ */ jsx("span", { className: "srOnly", children: "（新窗口打开）" })
    ] })
  ] });
}
const footer = "_footer_ijc92_1";
const inner$1 = "_inner_ijc92_7";
const info = "_info_ijc92_14";
const email = "_email_ijc92_20";
const links = "_links_ijc92_25";
const link = "_link_ijc92_25";
const meta$2 = "_meta_ijc92_36";
const styles$b = {
  footer,
  inner: inner$1,
  info,
  email,
  links,
  link,
  meta: meta$2
};
function SiteFooter() {
  const buildYear = 2026;
  return /* @__PURE__ */ jsx("footer", { className: styles$b.footer, children: /* @__PURE__ */ jsxs("div", { className: "container", children: [
    /* @__PURE__ */ jsxs("div", { className: styles$b.inner, children: [
      /* @__PURE__ */ jsxs("div", { className: styles$b.info, children: [
        /* @__PURE__ */ jsx(CopyEmailButton, { className: styles$b.email }),
        /* @__PURE__ */ jsxs("span", { className: styles$b.meta, style: { margin: 0 }, children: [
          site.location,
          " · ",
          site.availability ?? site.role
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: styles$b.links, children: site.social.map((item2) => /* @__PURE__ */ jsx(ExternalLink, { href: item2.href, className: styles$b.link, children: item2.label }, item2.label)) })
    ] }),
    /* @__PURE__ */ jsxs("p", { className: styles$b.meta, children: [
      "© ",
      buildYear,
      " ",
      site.name,
      " · 由 Vite 静态构建"
    ] })
  ] }) });
}
const overlay = "_overlay_jri9q_1";
const topBar = "_topBar_jri9q_22";
const closeButton = "_closeButton_jri9q_31";
const nav$1 = "_nav_jri9q_39";
const navLink$1 = "_navLink_jri9q_46";
const styles$a = {
  overlay,
  topBar,
  closeButton,
  nav: nav$1,
  navLink: navLink$1
};
const FOCUSABLE = "a[href], button:not([disabled])";
function MobileDrawer({ open, showBlog, onClose }) {
  const drawerRef = useRef(null);
  useEffect(() => {
    var _a;
    if (!open) {
      return;
    }
    document.body.style.overflow = "hidden";
    const drawer = drawerRef.current;
    (_a = drawer == null ? void 0 : drawer.querySelector(FOCUSABLE)) == null ? void 0 : _a.focus();
    const onKeyDown = (event) => {
      if (event.key === "Escape") {
        onClose();
        return;
      }
      if (event.key === "Tab" && drawer) {
        const focusables = [...drawer.querySelectorAll(FOCUSABLE)];
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = "";
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [open, onClose]);
  if (!open) {
    return null;
  }
  return /* @__PURE__ */ jsxs("div", { ref: drawerRef, id: "mobile-drawer", className: styles$a.overlay, role: "dialog", "aria-modal": "true", "aria-label": "导航菜单", children: [
    /* @__PURE__ */ jsx("div", { className: styles$a.topBar, children: /* @__PURE__ */ jsx("button", { type: "button", className: styles$a.closeButton, "aria-label": "关闭导航菜单", onClick: onClose, children: /* @__PURE__ */ jsx(CloseIcon, {}) }) }),
    /* @__PURE__ */ jsxs("nav", { className: styles$a.nav, "aria-label": "移动端导航", children: [
      /* @__PURE__ */ jsx(Link, { to: "/about", className: styles$a.navLink, onClick: onClose, children: "关于" }),
      /* @__PURE__ */ jsx(Link, { to: "/projects", className: styles$a.navLink, onClick: onClose, children: "项目" }),
      showBlog && /* @__PURE__ */ jsx(Link, { to: "/blog", className: styles$a.navLink, onClick: onClose, children: "博客" }),
      /* @__PURE__ */ jsx(Link, { to: "/#contact", className: styles$a.navLink, onClick: onClose, children: "联系我" })
    ] })
  ] });
}
const header = "_header_pkub3_1";
const scrolled = "_scrolled_pkub3_14";
const inner = "_inner_pkub3_19";
const brand = "_brand_pkub3_29";
const nav = "_nav_pkub3_39";
const navLink = "_navLink_pkub3_45";
const active = "_active_pkub3_58";
const menuButton = "_menuButton_pkub3_64";
const styles$9 = {
  header,
  scrolled,
  inner,
  brand,
  nav,
  navLink,
  active,
  menuButton
};
function SiteHeader({ showBlog }) {
  const [scrolled2, setScrolled] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const menuButtonRef = useRef(null);
  const location2 = useLocation();
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 120);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  useEffect(() => {
    setDrawerOpen(false);
  }, [location2.pathname]);
  return /* @__PURE__ */ jsxs("header", { className: `${styles$9.header} ${scrolled2 ? styles$9.scrolled : ""}`, children: [
    /* @__PURE__ */ jsxs("div", { className: styles$9.inner, children: [
      /* @__PURE__ */ jsx(Link, { to: "/", className: styles$9.brand, children: site.name }),
      /* @__PURE__ */ jsxs("nav", { className: styles$9.nav, "aria-label": "主导航", children: [
        /* @__PURE__ */ jsx(NavLink, { to: "/about", className: ({ isActive }) => `${styles$9.navLink} ${isActive ? styles$9.active : ""}`, children: "关于" }),
        /* @__PURE__ */ jsx(
          NavLink,
          {
            to: "/projects",
            className: ({ isActive }) => `${styles$9.navLink} ${isActive ? styles$9.active : ""}`,
            children: "项目"
          }
        ),
        showBlog && /* @__PURE__ */ jsx(NavLink, { to: "/blog", className: ({ isActive }) => `${styles$9.navLink} ${isActive ? styles$9.active : ""}`, children: "博客" }),
        /* @__PURE__ */ jsx(Link, { to: "/#contact", className: "btn btnPrimary", children: "联系我" })
      ] }),
      /* @__PURE__ */ jsx(
        "button",
        {
          ref: menuButtonRef,
          type: "button",
          className: styles$9.menuButton,
          "aria-label": "打开导航菜单",
          "aria-expanded": drawerOpen,
          "aria-controls": "mobile-drawer",
          onClick: () => setDrawerOpen(true),
          children: /* @__PURE__ */ jsx(MenuIcon, {})
        }
      )
    ] }),
    /* @__PURE__ */ jsx(
      MobileDrawer,
      {
        open: drawerOpen,
        showBlog,
        onClose: () => {
          var _a;
          setDrawerOpen(false);
          (_a = menuButtonRef.current) == null ? void 0 : _a.focus();
        }
      }
    )
  ] });
}
function focusPageHeading() {
  if (typeof document === "undefined") {
    return;
  }
  const heading = document.querySelector("main h1");
  if (heading instanceof HTMLElement) {
    if (!heading.hasAttribute("tabindex")) {
      heading.setAttribute("tabindex", "-1");
    }
    heading.focus({ preventScroll: true });
  }
}
function SiteLayout() {
  const location2 = useLocation();
  const { pathname, hash } = location2;
  useEffect(() => {
    if (hash) {
      const target = document.querySelector(hash);
      if (target) {
        target.scrollIntoView({ block: "start" });
        return;
      }
    }
    window.scrollTo(0, 0);
    focusPageHeading();
  }, [pathname, hash]);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("a", { href: "#main", className: "skipLink", children: "跳到主要内容" }),
    /* @__PURE__ */ jsx(Seo, {}),
    /* @__PURE__ */ jsx(SiteHeader, { showBlog: allPosts.length > 0 }),
    /* @__PURE__ */ jsx("main", { id: "main", children: /* @__PURE__ */ jsx(Outlet, {}) }),
    /* @__PURE__ */ jsx(SiteFooter, {})
  ] });
}
const group = "_group_x1ljy_1";
const groupTitle = "_groupTitle_x1ljy_5";
const items = "_items_x1ljy_12";
const item$1 = "_item_x1ljy_12";
const tag$1 = "_tag_x1ljy_22";
const usage = "_usage_x1ljy_41";
const styles$8 = {
  group,
  groupTitle,
  items,
  item: item$1,
  tag: tag$1,
  usage
};
function SkillGroup({ group: group2 }) {
  if (group2.items.length === 0) {
    return null;
  }
  return /* @__PURE__ */ jsxs("div", { className: styles$8.group, children: [
    /* @__PURE__ */ jsx("h3", { className: styles$8.groupTitle, children: group2.group }),
    /* @__PURE__ */ jsx("ul", { className: styles$8.items, children: group2.items.map((item2) => /* @__PURE__ */ jsxs("li", { className: styles$8.item, children: [
      /* @__PURE__ */ jsx(Link, { to: `/projects?tag=${encodeURIComponent(item2.name)}`, className: styles$8.tag, children: item2.name }),
      /* @__PURE__ */ jsx("span", { className: styles$8.usage, children: item2.usage })
    ] }, item2.name)) })
  ] });
}
const timeline = "_timeline_bcul9_1";
const item = "_item_bcul9_7";
const dot = "_dot_bcul9_17";
const current = "_current_bcul9_27";
const period = "_period_bcul9_31";
const title$4 = "_title_bcul9_36";
const outcome = "_outcome_bcul9_42";
const styles$7 = {
  timeline,
  item,
  dot,
  current,
  period,
  title: title$4,
  outcome
};
function Timeline({ items: items2 }) {
  if (items2.length === 0) {
    return null;
  }
  return /* @__PURE__ */ jsx("ol", { className: styles$7.timeline, children: items2.map((item2) => /* @__PURE__ */ jsxs("li", { className: `${styles$7.item} ${item2.current ? styles$7.current : ""}`, children: [
    /* @__PURE__ */ jsx("span", { className: styles$7.dot, "aria-hidden": "true" }),
    /* @__PURE__ */ jsx("p", { className: styles$7.period, children: item2.period }),
    /* @__PURE__ */ jsxs("h3", { className: styles$7.title, children: [
      item2.company,
      " · ",
      item2.title
    ] }),
    /* @__PURE__ */ jsx("p", { className: styles$7.outcome, children: item2.outcome })
  ] }, `${item2.company}-${item2.period}`)) });
}
const skills = [
  {
    group: "语言",
    items: [
      { name: "TypeScript", usage: "全站与工具链的主要开发语言" },
      { name: "JavaScript", usage: "浏览器端脚本与遗留模块维护" },
      { name: "CSS", usage: "设计系统与响应式布局落地" }
    ]
  },
  {
    group: "框架",
    items: [
      { name: "React", usage: "本站与多个中后台项目的主力框架" },
      { name: "React Router", usage: "多页静态站的路由与预渲染" }
    ]
  },
  {
    group: "工具",
    items: [
      { name: "Vite", usage: "开发与构建工具链，自定义预渲染流程" },
      { name: "Git", usage: "日常协作与内容版本管理" }
    ]
  },
  {
    group: "领域",
    items: [
      { name: "构建性能", usage: "产物体积预算、按需加载与缓存策略" },
      { name: "Web 无障碍", usage: "键盘可达、读屏兼容与对比度基线" }
    ]
  }
];
function AboutPage() {
  return /* @__PURE__ */ jsxs("div", { className: "container section", style: { maxWidth: "var(--prose)" }, children: [
    /* @__PURE__ */ jsx("h1", { style: { fontSize: "30px", marginBottom: "var(--space-4)" }, children: "关于" }),
    /* @__PURE__ */ jsxs("section", { style: { marginBottom: "var(--space-6)" }, children: [
      /* @__PURE__ */ jsxs("p", { children: [
        "我是",
        site.name,
        "，",
        site.tagline,
        "。目前",
        site.availability ?? site.role,
        "，坐标",
        site.location,
        "。"
      ] }),
      /* @__PURE__ */ jsxs("p", { children: [
        "我相信工程判断比技术清单更重要：每个项目为什么这么做、舍弃了什么、结果如何验证， 这些过程信息都写在了",
        /* @__PURE__ */ jsx(Link, { to: "/projects", children: "项目页" }),
        "里。"
      ] }),
      /* @__PURE__ */ jsx("p", { children: "工作之外，我把实践整理成文章，持续输出。" })
    ] }),
    experiences.length > 0 && /* @__PURE__ */ jsxs("section", { style: { marginBottom: "var(--space-6)" }, children: [
      /* @__PURE__ */ jsx("h2", { className: "sectionTitle", children: "经历" }),
      /* @__PURE__ */ jsx(Timeline, { items: experiences })
    ] }),
    /* @__PURE__ */ jsxs("section", { style: { marginBottom: "var(--space-6)" }, children: [
      /* @__PURE__ */ jsx("h2", { className: "sectionTitle", children: "技能" }),
      skills.map((group2) => /* @__PURE__ */ jsx(SkillGroup, { group: group2 }, group2.group))
    ] }),
    /* @__PURE__ */ jsxs("section", { style: { marginBottom: "var(--space-6)" }, children: [
      /* @__PURE__ */ jsx("h2", { className: "sectionTitle", children: "教育" }),
      /* @__PURE__ */ jsx("ul", { children: education.map((item2) => /* @__PURE__ */ jsxs("li", { style: { marginBottom: "var(--space-2)" }, children: [
        /* @__PURE__ */ jsx("strong", { children: item2.school }),
        " · ",
        item2.major,
        " ·",
        " ",
        /* @__PURE__ */ jsx("span", { style: { color: "var(--muted)" }, children: item2.period })
      ] }, item2.school)) })
    ] }),
    /* @__PURE__ */ jsxs("section", { style: { marginBottom: "var(--space-6)" }, children: [
      /* @__PURE__ */ jsx("h2", { className: "sectionTitle", children: "当前在做什么" }),
      /* @__PURE__ */ jsx("ul", { style: { listStyle: "disc", paddingLeft: "var(--space-4)" }, children: currentFocus.map((item2) => /* @__PURE__ */ jsx("li", { children: item2 }, item2)) })
    ] }),
    /* @__PURE__ */ jsxs("section", { children: [
      /* @__PURE__ */ jsx("h2", { className: "sectionTitle", children: "联系方式" }),
      /* @__PURE__ */ jsx(CopyEmailButton, {})
    ] })
  ] });
}
const empty = "_empty_1tktb_1";
const text = "_text_1tktb_9";
const styles$6 = {
  empty,
  text
};
function EmptyState({ message, actionLabel, actionHref }) {
  return /* @__PURE__ */ jsxs("div", { className: styles$6.empty, children: [
    /* @__PURE__ */ jsx("p", { className: styles$6.text, children: message }),
    /* @__PURE__ */ jsx(Link, { to: actionHref, className: "btn btnSecondary", children: actionLabel })
  ] });
}
const row = "_row_pevi9_1";
const title$3 = "_title_pevi9_12";
const summary$1 = "_summary_pevi9_22";
const meta$1 = "_meta_pevi9_32";
const styles$5 = {
  row,
  title: title$3,
  summary: summary$1,
  meta: meta$1
};
function PostRow({ post }) {
  return /* @__PURE__ */ jsxs(Link, { to: post.href, className: styles$5.row, children: [
    /* @__PURE__ */ jsx("h3", { className: styles$5.title, children: post.title }),
    /* @__PURE__ */ jsx("p", { className: styles$5.summary, children: post.summary }),
    /* @__PURE__ */ jsxs("span", { className: styles$5.meta, children: [
      /* @__PURE__ */ jsx("time", { dateTime: post.date, children: post.displayDate }),
      /* @__PURE__ */ jsxs("span", { children: [
        "约 ",
        post.readingMinutes,
        " 分钟"
      ] }),
      post.tags.map((tag2) => /* @__PURE__ */ jsxs("span", { children: [
        "#",
        tag2
      ] }, tag2))
    ] })
  ] });
}
const title$2 = "_title_1j95q_1";
const count = "_count_1j95q_6";
const year = "_year_1j95q_12";
const yearGroup = "_yearGroup_1j95q_18";
const styles$4 = {
  title: title$2,
  count,
  year,
  yearGroup
};
function BlogListPage() {
  if (allPosts.length === 0) {
    return /* @__PURE__ */ jsxs("div", { className: "container section", children: [
      /* @__PURE__ */ jsx("h1", { className: styles$4.title, children: "博客" }),
      /* @__PURE__ */ jsx(EmptyState, { message: "暂无文章，正在整理中。", actionLabel: "返回首页", actionHref: "/" })
    ] });
  }
  const groups = groupPostsByYear(allPosts);
  return /* @__PURE__ */ jsxs("div", { className: "container section", children: [
    /* @__PURE__ */ jsx("h1", { className: styles$4.title, children: "博客" }),
    /* @__PURE__ */ jsxs("p", { className: styles$4.count, children: [
      "共 ",
      allPosts.length,
      " 篇"
    ] }),
    groups.map((group2) => /* @__PURE__ */ jsxs("section", { children: [
      /* @__PURE__ */ jsx("h2", { className: styles$4.year, children: group2.year }),
      /* @__PURE__ */ jsx("div", { className: styles$4.yearGroup, children: group2.posts.map((post) => /* @__PURE__ */ jsx(PostRow, { post }, post.slug)) })
    ] }, group2.year))
  ] });
}
const card = "_card_nqrhx_1";
const titleLink = "_titleLink_nqrhx_25";
const external = "_external_nqrhx_50";
const cover = "_cover_nqrhx_56";
const title$1 = "_title_nqrhx_25";
const summary = "_summary_nqrhx_75";
const meta = "_meta_nqrhx_85";
const tags = "_tags_nqrhx_90";
const styles$3 = {
  card,
  titleLink,
  external,
  cover,
  title: title$1,
  summary,
  meta,
  tags
};
function ProjectCard({ project }) {
  const external2 = project.links[0];
  return /* @__PURE__ */ jsxs("article", { className: styles$3.card, children: [
    /* @__PURE__ */ jsx("div", { className: styles$3.cover, "aria-hidden": "true", children: project.title.slice(0, 1) }),
    /* @__PURE__ */ jsx("h3", { className: styles$3.title, children: /* @__PURE__ */ jsx(Link, { to: project.href, className: styles$3.titleLink, children: project.title }) }),
    /* @__PURE__ */ jsx("p", { className: styles$3.summary, children: project.summary }),
    /* @__PURE__ */ jsxs("p", { className: styles$3.meta, children: [
      project.role,
      " · ",
      project.period
    ] }),
    /* @__PURE__ */ jsxs("div", { className: styles$3.tags, children: [
      project.stack.slice(0, 3).map((tag2) => /* @__PURE__ */ jsx("span", { className: "chip", children: tag2 }, tag2)),
      external2 && /* @__PURE__ */ jsxs(
        "a",
        {
          href: external2.href,
          target: "_blank",
          rel: "noopener noreferrer",
          className: `chip ${styles$3.external}`,
          "aria-label": `${external2.label}（新窗口打开）`,
          children: [
            external2.label,
            " ↗"
          ]
        }
      )
    ] })
  ] });
}
function ResumeButton({ className }) {
  const [downloading, setDownloading] = useState(false);
  const timerRef = useRef(null);
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, []);
  if (!site.resumeUrl) {
    return /* @__PURE__ */ jsx("a", { href: `mailto:${site.email}`, className: `btn btnSecondary ${className ?? ""}`, children: "简历暂不可用，可邮件联系" });
  }
  return /* @__PURE__ */ jsx(
    "a",
    {
      href: site.resumeUrl,
      download: true,
      className: `btn btnSecondary ${className ?? ""}`,
      onClick: () => {
        setDownloading(true);
        if (timerRef.current) {
          clearTimeout(timerRef.current);
        }
        timerRef.current = setTimeout(() => setDownloading(false), 1500);
      },
      children: downloading ? "正在下载…" : "下载简历"
    }
  );
}
const hero = "_hero_go54o_1";
const heroText = "_heroText_go54o_8";
const role = "_role_go54o_12";
const name = "_name_go54o_19";
const tagline = "_tagline_go54o_25";
const location = "_location_go54o_31";
const cta = "_cta_go54o_37";
const avatar = "_avatar_go54o_43";
const grid$1 = "_grid_go54o_57";
const postList = "_postList_go54o_89";
const contact = "_contact_go54o_93";
const contactInner = "_contactInner_go54o_100";
const contactText = "_contactText_go54o_106";
const styles$2 = {
  hero,
  heroText,
  role,
  name,
  tagline,
  location,
  cta,
  avatar,
  grid: grid$1,
  postList,
  contact,
  contactInner,
  contactText
};
function HomePage() {
  const featured = featuredProjects(allProjects);
  const posts = latestPosts(allPosts);
  const skillSummary = skills.map((group2) => ({ ...group2, items: group2.items.slice(0, 6) })).filter((group2) => group2.items.length > 0);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("section", { className: `container ${styles$2.hero} sectionIn`, children: [
      /* @__PURE__ */ jsxs("div", { className: styles$2.heroText, children: [
        /* @__PURE__ */ jsx("p", { className: styles$2.role, children: site.role }),
        /* @__PURE__ */ jsx("h1", { className: styles$2.name, children: site.name }),
        /* @__PURE__ */ jsx("p", { className: styles$2.tagline, children: site.tagline }),
        /* @__PURE__ */ jsxs("p", { className: styles$2.location, children: [
          site.location,
          site.availability ? ` · ${site.availability}` : ""
        ] }),
        /* @__PURE__ */ jsxs("div", { className: styles$2.cta, children: [
          /* @__PURE__ */ jsx(Link, { to: "/projects", className: "btn btnPrimary", children: "查看项目" }),
          /* @__PURE__ */ jsx(ResumeButton, {})
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: styles$2.avatar, "aria-hidden": "true", children: site.name.slice(0, 1) })
    ] }),
    /* @__PURE__ */ jsx("section", { className: "section", children: /* @__PURE__ */ jsxs("div", { className: "container", children: [
      /* @__PURE__ */ jsx("h2", { className: "sectionTitle", children: "技能" }),
      skillSummary.map((group2) => /* @__PURE__ */ jsx(SkillGroup, { group: group2 }, group2.group))
    ] }) }),
    /* @__PURE__ */ jsx("section", { className: "section", children: /* @__PURE__ */ jsxs("div", { className: "container", children: [
      /* @__PURE__ */ jsx("h2", { className: "sectionTitle", children: "精选项目" }),
      featured.length === 0 ? /* @__PURE__ */ jsx(EmptyState, { message: "项目正在整理中，欢迎先通过邮件了解我的工作。", actionLabel: "联系我", actionHref: "/#contact" }) : /* @__PURE__ */ jsx("div", { className: styles$2.grid, children: featured.map((project) => /* @__PURE__ */ jsx(ProjectCard, { project }, project.slug)) })
    ] }) }),
    posts.length > 0 && /* @__PURE__ */ jsx("section", { className: "section", children: /* @__PURE__ */ jsxs("div", { className: "container", children: [
      /* @__PURE__ */ jsx("h2", { className: "sectionTitle", children: "最新文章" }),
      /* @__PURE__ */ jsx("div", { className: styles$2.postList, children: posts.map((post) => /* @__PURE__ */ jsx(PostRow, { post }, post.slug)) })
    ] }) }),
    /* @__PURE__ */ jsx("section", { id: "contact", className: `section ${styles$2.contact}`, children: /* @__PURE__ */ jsxs("div", { className: `container ${styles$2.contactInner}`, children: [
      /* @__PURE__ */ jsx("h2", { className: "sectionTitle", children: "联系我" }),
      /* @__PURE__ */ jsx("p", { className: styles$2.contactText, children: "对我的经历感兴趣，或想聊聊合作？邮件是最快的方式。" }),
      /* @__PURE__ */ jsx(CopyEmailButton, {})
    ] }) })
  ] });
}
function NotFoundPage() {
  const recommended = featuredProjects(allProjects);
  return /* @__PURE__ */ jsxs("div", { className: "container section", style: { maxWidth: "var(--prose)" }, children: [
    /* @__PURE__ */ jsx("h1", { style: { fontSize: "30px", marginBottom: "var(--space-3)" }, children: "页面不存在" }),
    /* @__PURE__ */ jsx("p", { style: { color: "var(--ink-2)", marginBottom: "var(--space-4)" }, children: "这个页面可能已移动或删除。你可以返回首页，或看看这些项目：" }),
    /* @__PURE__ */ jsx(Link, { to: "/", className: "btn btnPrimary", children: "返回首页" }),
    recommended.length > 0 && /* @__PURE__ */ jsxs("div", { style: { marginTop: "var(--space-6)" }, children: [
      /* @__PURE__ */ jsx("h2", { className: "sectionTitle", children: "推荐项目" }),
      /* @__PURE__ */ jsx("ul", { style: { listStyle: "disc", paddingLeft: "var(--space-4)" }, children: recommended.map((project) => /* @__PURE__ */ jsxs("li", { style: { marginBottom: "var(--space-2)" }, children: [
        /* @__PURE__ */ jsx(Link, { to: project.href, children: project.title }),
        /* @__PURE__ */ jsxs("span", { style: { color: "var(--muted)" }, children: [
          " — ",
          project.summary
        ] })
      ] }, project.slug)) })
    ] })
  ] });
}
const bar = "_bar_1iir4_1";
const tag = "_tag_1iir4_7";
const selected = "_selected_1iir4_26";
const styles$1 = {
  bar,
  tag,
  selected
};
function TagFilter({ tags: tags2, selected: selected2, onSelect }) {
  return /* @__PURE__ */ jsxs("div", { className: styles$1.bar, role: "group", "aria-label": "按技术栈筛选", children: [
    /* @__PURE__ */ jsx(
      "button",
      {
        type: "button",
        className: `${styles$1.tag} ${selected2 === null ? styles$1.selected : ""}`,
        "aria-pressed": selected2 === null,
        onClick: () => onSelect(null),
        children: "全部"
      }
    ),
    tags2.map(({ tag: tag2, count: count2 }) => /* @__PURE__ */ jsxs(
      "button",
      {
        type: "button",
        className: `${styles$1.tag} ${selected2 === tag2 ? styles$1.selected : ""}`,
        "aria-pressed": selected2 === tag2,
        onClick: () => onSelect(selected2 === tag2 ? null : tag2),
        children: [
          tag2,
          " · ",
          count2
        ]
      },
      tag2
    ))
  ] });
}
const grid = "_grid_1bozq_1";
const lead = "_lead_1bozq_20";
const more = "_more_1bozq_25";
const title = "_title_1bozq_30";
const styles = {
  grid,
  lead,
  more,
  title
};
const PAGE_SIZE = 12;
function ProjectListPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const selected2 = searchParams.get("tag");
  const tags2 = collectProjectTags(allProjects);
  const filtered = filterProjectsByTag(allProjects, selected2);
  const visible = filtered.slice(0, visibleCount);
  const onSelect = (tag2) => {
    setVisibleCount(PAGE_SIZE);
    setSearchParams(tag2 ? { tag: tag2 } : {}, { replace: true });
  };
  return /* @__PURE__ */ jsxs("div", { className: "container section", children: [
    /* @__PURE__ */ jsx("h1", { className: styles.title, children: "项目" }),
    /* @__PURE__ */ jsx("p", { className: styles.lead, children: "每个项目都写清了问题、方案与结果。按技术栈筛选，或直接看全部。" }),
    /* @__PURE__ */ jsx(TagFilter, { tags: tags2, selected: selected2, onSelect }),
    visible.length === 0 ? /* @__PURE__ */ jsx("div", { style: { marginTop: "var(--space-4)" }, children: /* @__PURE__ */ jsx(
      EmptyState,
      {
        message: `没有用「${selected2}」做的项目。`,
        actionLabel: "查看全部项目",
        actionHref: "/projects"
      }
    ) }) : /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("div", { className: styles.grid, children: visible.map((project) => /* @__PURE__ */ jsx(ProjectCard, { project }, project.slug)) }),
      filtered.length > visibleCount && /* @__PURE__ */ jsx("div", { className: styles.more, children: /* @__PURE__ */ jsxs("button", { type: "button", className: "btn btnSecondary", onClick: () => setVisibleCount(filtered.length), children: [
        "加载更多（剩余 ",
        filtered.length - visibleCount,
        " 个）"
      ] }) })
    ] })
  ] });
}
const ProjectDetailPage = lazy(() => import("./assets/ProjectDetailPage-DXGNNKI6.js"));
const BlogDetailPage = lazy(() => import("./assets/BlogDetailPage-XZa35tKe.js"));
function AppRoutes() {
  return /* @__PURE__ */ jsxs(Route, { element: /* @__PURE__ */ jsx(SiteLayout, {}), children: [
    /* @__PURE__ */ jsx(Route, { index: true, element: /* @__PURE__ */ jsx(HomePage, {}) }),
    /* @__PURE__ */ jsx(Route, { path: "about", element: /* @__PURE__ */ jsx(AboutPage, {}) }),
    /* @__PURE__ */ jsx(Route, { path: "projects", element: /* @__PURE__ */ jsx(ProjectListPage, {}) }),
    /* @__PURE__ */ jsx(Route, { path: "projects/:slug", element: /* @__PURE__ */ jsx(ProjectDetailPage, {}) }),
    /* @__PURE__ */ jsx(Route, { path: "blog", element: /* @__PURE__ */ jsx(BlogListPage, {}) }),
    /* @__PURE__ */ jsx(Route, { path: "blog/:slug", element: /* @__PURE__ */ jsx(BlogDetailPage, {}) }),
    /* @__PURE__ */ jsx(Route, { path: "404", element: /* @__PURE__ */ jsx(NotFoundPage, {}) }),
    /* @__PURE__ */ jsx(Route, { path: "*", element: /* @__PURE__ */ jsx(NotFoundPage, {}) })
  ] });
}
function App() {
  return /* @__PURE__ */ jsx(Suspense, { fallback: null, children: /* @__PURE__ */ jsx(Routes, { children: AppRoutes() }) });
}
function render(url) {
  return new Promise((resolvePromise, reject) => {
    let app = "";
    const sink = new Writable({
      write(chunk, _encoding, callback) {
        app += chunk.toString();
        callback();
      }
    });
    sink.on("finish", () => {
      resolvePromise({ app, head: renderHead(resolveMeta(url)) });
    });
    const { pipe } = renderToPipeableStream(
      /* @__PURE__ */ jsx(StaticRouter, { location: url, basename: BASE_PATH, children: /* @__PURE__ */ jsx(App, {}) }),
      {
        onAllReady() {
          pipe(sink);
        },
        onError(error) {
          reject(error);
        }
      }
    );
  });
}
export {
  ArrowLeftIcon as A,
  ExternalLink as E,
  allProjects as a,
  findPost as b,
  postPrevNext as c,
  allPosts as d,
  findProject as f,
  projectPrevNext as p,
  render,
  site as s
};
