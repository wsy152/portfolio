/**
 * 预渲染：遍历全部已发布路由 → renderToString → 注入 head/app → 写 dist 目录。
 * 末尾生成 sitemap.xml，并校验每个预期路径都产出了 HTML（缺一个即构建失败）。
 * 草稿不进入路由枚举，自然不产出页面、不进 sitemap。
 */
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { publishedPosts, publishedProjects } from '../src/lib/content';
import { loadContent } from '../src/lib/content-build';
import { BASE_PATH, SITE_URL } from '../src/lib/base';

interface RenderResult {
  app: string;
  head: string;
}
type RenderFn = (url: string) => Promise<RenderResult>;

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const DIST = join(ROOT, 'dist');

const { data } = await loadContent();
const projects = publishedProjects(data.projects, false);
const posts = publishedPosts(data.posts, false);

const urls: string[] = ['/', '/about', '/projects', '/404'];
if (posts.length > 0) {
  urls.push('/blog');
}
for (const project of projects) {
  urls.push(project.href);
}
for (const post of posts) {
  urls.push(post.href);
}

const { render } = (await import(pathToFileURL(join(ROOT, 'dist-ssr/entry-server.js')).href)) as {
  render: RenderFn;
};

const template = readFileSync(join(DIST, 'index.html'), 'utf-8');

for (const url of urls) {
  const { app, head } = await render(url);
  const html = template.replace('<!--head-->', head).replace('<!--app-->', app);
  if (url === '/') {
    writeFileSync(join(DIST, 'index.html'), html);
    continue;
  }
  if (url === '/404') {
    writeFileSync(join(DIST, '404.html'), html);
    continue;
  }
  // 目录索引（/x/ 与 GitHub Pages 等托管） + 扁平副本（/x 直接被静态服务器命中），两种访问形式都不会落到首页
  mkdirSync(join(DIST, url), { recursive: true });
  writeFileSync(join(DIST, url, 'index.html'), html);
  writeFileSync(join(DIST, `${url}.html`), html);
}

// sitemap（草稿与 404 不进入）
const base = `${SITE_URL}${BASE_PATH === '/' ? '' : BASE_PATH}`;
const sitemapUrls = urls.filter((u) => u !== '/404');
const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${sitemapUrls.map((u) => `  <url><loc>${base}${u === '/' ? '/' : u}</loc></url>`).join('\n')}
</urlset>
`;
writeFileSync(join(DIST, 'sitemap.xml'), sitemap);

// 完整性校验：每个预期路径都必须有 HTML
const missing = urls.filter((url) => {
  const file =
    url === '/' ? join(DIST, 'index.html') : url === '/404' ? join(DIST, '404.html') : join(DIST, url, 'index.html');
  return !existsSync(file);
});
if (missing.length > 0) {
  console.error(`预渲染缺失页面：\n${missing.join('\n')}`);
  process.exit(1);
}

console.log(`预渲染完成：${urls.length} 个页面 + sitemap.xml`);
