// 站点基础路径：根路径部署为 '/'；子路径部署时改为 '/portfolio/' 等形式。
// 该常量同时驱动 Vite base、路由 basename、canonical 与 sitemap，禁止在三处各写一遍。
export const BASE_PATH = '/';

// 站点绝对地址（TBD：上线前替换为真实域名），用于 canonical / og:url / sitemap
export const SITE_URL = 'https://example.com';
