/**
 * 技能分组（示例占位数据）。分组固定为：语言、框架、工具、领域。
 * 不使用百分比或星级，每项只写一句「用在什么地方」。
 */
export interface SkillItem {
  name: string;
  usage: string;
}

export interface SkillGroup {
  group: string;
  items: SkillItem[];
}

export const skills: SkillGroup[] = [
  {
    group: '语言',
    items: [
      { name: 'TypeScript', usage: '全站与工具链的主要开发语言' },
      { name: 'JavaScript', usage: '浏览器端脚本与遗留模块维护' },
      { name: 'CSS', usage: '设计系统与响应式布局落地' },
    ],
  },
  {
    group: '框架',
    items: [
      { name: 'React', usage: '本站与多个中后台项目的主力框架' },
      { name: 'React Router', usage: '多页静态站的路由与预渲染' },
    ],
  },
  {
    group: '工具',
    items: [
      { name: 'Vite', usage: '开发与构建工具链，自定义预渲染流程' },
      { name: 'Git', usage: '日常协作与内容版本管理' },
    ],
  },
  {
    group: '领域',
    items: [
      { name: '构建性能', usage: '产物体积预算、按需加载与缓存策略' },
      { name: 'Web 无障碍', usage: '键盘可达、读屏兼容与对比度基线' },
    ],
  },
];
