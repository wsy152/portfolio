---
title: 示例 · 预渲染时的三个坑
slug: prerender-pitfalls
date: 2026-07-03
tags: [React, SSR]
---

> 本文是示例内容，用于演示「无摘要时自动截取正文」的列表样式。

## 渲染期访问浏览器 API

示例内容：预渲染在 Node 中执行，任何 `window`、`document` 访问都会抛错，必须放进 `useEffect`。

## Hydration 不一致

示例内容：`new Date()`、`Math.random()` 这类不确定值会让两端渲染结果不同，应改成构建期常量。

## 路由表分散

示例内容：客户端与预渲染必须共用同一份路由定义，否则线上直接访问子路径会 404。
