import { jsx } from "react/jsx-runtime";
import { useRef, useEffect } from "react";
function MarkdownBody({ html }) {
  const containerRef = useRef(null);
  useEffect(() => {
    const container = containerRef.current;
    if (!container) {
      return;
    }
    const onClick = async (event) => {
      var _a;
      const button = event.target.closest(".codeCopy");
      if (!button) {
        return;
      }
      const pre = (_a = button.parentElement) == null ? void 0 : _a.querySelector("pre");
      const text = (pre == null ? void 0 : pre.textContent) ?? "";
      try {
        await navigator.clipboard.writeText(text);
        button.textContent = "已复制";
        setTimeout(() => {
          button.textContent = "复制";
        }, 2e3);
      } catch {
        button.textContent = "复制失败";
      }
    };
    container.addEventListener("click", onClick);
    return () => container.removeEventListener("click", onClick);
  }, []);
  return /* @__PURE__ */ jsx("div", { ref: containerRef, className: "prose", dangerouslySetInnerHTML: { __html: html } });
}
const rawBodies = { "projects": { "metrics-platform": { "bodyHtml": '<blockquote>\n<p>本文是示例内容，用于演示项目详情的版式，所有数据均为占位。</p>\n</blockquote>\n<h2 id="user-content-背景与挑战">背景与挑战</h2>\n<p>示例内容：监控能力分散在 12 个独立页面，排障时需要人工在页面之间对照数据。挑战在于信息架构需要重新设计，同时保持与既有告警系统的兼容。</p>\n<h2 id="user-content-方案与取舍">方案与取舍</h2>\n<p>示例内容：采用单页工作台方案，以路由级下钻代替页面跳转。取舍点在于首屏数据量上升，通过按面板懒加载与 WebSocket 增量推送控制。</p>\n<div class="codeBlock"><button class="codeCopy" type="button" aria-label="复制代码">复制</button><pre class="shiki github-light" style="background-color:#fff;color:#24292e" tabindex="0"><code><span class="line"><span style="color:#6A737D">// 示例代码：面板按需订阅</span></span>\n<span class="line"><span style="color:#D73A49">function</span><span style="color:#6F42C1"> usePanelSubscription</span><span style="color:#24292E">(</span><span style="color:#E36209">panelId</span><span style="color:#D73A49">:</span><span style="color:#005CC5"> string</span><span style="color:#24292E">) {</span></span>\n<span class="line"><span style="color:#6F42C1">  useEffect</span><span style="color:#24292E">(() </span><span style="color:#D73A49">=></span><span style="color:#24292E"> {</span></span>\n<span class="line"><span style="color:#D73A49">    const</span><span style="color:#005CC5"> channel</span><span style="color:#D73A49"> =</span><span style="color:#6F42C1"> openChannel</span><span style="color:#24292E">(</span><span style="color:#032F62">`panel:${</span><span style="color:#24292E">panelId</span><span style="color:#032F62">}`</span><span style="color:#24292E">);</span></span>\n<span class="line"><span style="color:#D73A49">    return</span><span style="color:#24292E"> () </span><span style="color:#D73A49">=></span><span style="color:#24292E"> channel.</span><span style="color:#6F42C1">close</span><span style="color:#24292E">();</span></span>\n<span class="line"><span style="color:#24292E">  }, [panelId]);</span></span>\n<span class="line"><span style="color:#24292E">}</span></span></code></pre></div>\n<h2 id="user-content-关键决策">关键决策</h2>\n<p>示例内容：告警确认动作收拢到统一队列，避免多入口状态不一致。</p>\n<h2 id="user-content-结果与反思">结果与反思</h2>\n<p>示例内容：排障路径明显缩短。反思：早期低估了告警状态机的复杂度，应在原型期引入真实排障演练。</p>', "headings": [{ "depth": 2, "text": "背景与挑战", "id": "背景与挑战" }, { "depth": 2, "text": "方案与取舍", "id": "方案与取舍" }, { "depth": 2, "text": "关键决策", "id": "关键决策" }, { "depth": 2, "text": "结果与反思", "id": "结果与反思" }] }, "design-system": { "bodyHtml": '<blockquote>\n<p>本文是示例内容，用于演示项目详情版式。</p>\n</blockquote>\n<h2 id="user-content-背景与挑战">背景与挑战</h2>\n<p>示例内容：业务快速扩张期各团队独立实现组件，视觉走样、无障碍缺失。挑战在于迁移老页面时不能阻塞业务迭代。</p>\n<h2 id="user-content-方案与取舍">方案与取舍</h2>\n<p>示例内容：token 先行，组件随后，采用新旧并行的迁移策略。放弃了全量重写，选择按页面流量从高到低逐步替换。</p>\n<div class="codeBlock"><button class="codeCopy" type="button" aria-label="复制代码">复制</button><pre class="shiki github-light" style="background-color:#fff;color:#24292e" tabindex="0"><code><span class="line"><span style="color:#6A737D">/* 示例代码：token 定义 */</span></span>\n<span class="line"><span style="color:#6F42C1">:root</span><span style="color:#24292E"> {</span></span>\n<span class="line"><span style="color:#E36209">  --accent</span><span style="color:#24292E">: </span><span style="color:#005CC5">#2563eb</span><span style="color:#24292E">;</span></span>\n<span class="line"><span style="color:#E36209">  --radius</span><span style="color:#24292E">: </span><span style="color:#005CC5">10</span><span style="color:#D73A49">px</span><span style="color:#24292E">;</span></span>\n<span class="line"><span style="color:#24292E">}</span></span></code></pre></div>\n<h2 id="user-content-关键决策">关键决策</h2>\n<p>示例内容：不引入第三方 UI 库，全部组件自建以保证 token 一致性。</p>\n<h2 id="user-content-结果与反思">结果与反思</h2>\n<p>示例内容：新需求默认基于设计系统开发。反思：文档站应该与组件库同期建设，而非事后补齐。</p>', "headings": [{ "depth": 2, "text": "背景与挑战", "id": "背景与挑战" }, { "depth": 2, "text": "方案与取舍", "id": "方案与取舍" }, { "depth": 2, "text": "关键决策", "id": "关键决策" }, { "depth": 2, "text": "结果与反思", "id": "结果与反思" }] }, "draft-example": { "bodyHtml": "<p>示例草稿正文，不进入列表、不生成页面、不进入站点地图。</p>", "headings": [] }, "build-cache": { "bodyHtml": `<blockquote>
<p>本文是示例内容。该项目未设置结束时间，用于演示「进行中」的排序规则。</p>
</blockquote>
<h2 id="user-content-背景与挑战">背景与挑战</h2>
<p>示例内容：monorepo 下任何改动都触发全量构建。</p>
<h2 id="user-content-方案与取舍">方案与取舍</h2>
<p>示例内容：按「依赖层 / 类型层 / 产物层」分层缓存，取舍是缓存命中率的观测成本。</p>
<div class="codeBlock"><button class="codeCopy" type="button" aria-label="复制代码">复制</button><pre class="shiki github-light" style="background-color:#fff;color:#24292e" tabindex="0"><code><span class="line"><span style="color:#6A737D"># 示例代码：缓存 key 分层</span></span>
<span class="line"><span style="color:#24292E">- </span><span style="color:#22863A">uses</span><span style="color:#24292E">: </span><span style="color:#032F62">actions/cache@v4</span></span>
<span class="line"><span style="color:#22863A">  with</span><span style="color:#24292E">:</span></span>
<span class="line"><span style="color:#22863A">    path</span><span style="color:#24292E">: </span><span style="color:#032F62">node_modules</span></span>
<span class="line"><span style="color:#22863A">    key</span><span style="color:#24292E">: </span><span style="color:#032F62">deps-\${{ hashFiles('**/package-lock.json') }}</span></span></code></pre></div>
<h2 id="user-content-结果与反思">结果与反思</h2>
<p>示例内容：构建时间达标。反思：缓存失效策略需要与分支模型一起设计。</p>`, "headings": [{ "depth": 2, "text": "背景与挑战", "id": "背景与挑战" }, { "depth": 2, "text": "方案与取舍", "id": "方案与取舍" }, { "depth": 2, "text": "结果与反思", "id": "结果与反思" }] } }, "posts": { "how-this-site-is-built": { "bodyHtml": '<blockquote>\n<p>本文是示例内容，用于演示文章详情版式（目录、代码块、表格）。</p>\n</blockquote>\n<h2 id="user-content-为什么不用现成框架">为什么不用现成框架</h2>\n<p>示例内容：功能面很窄，只需要「Markdown → 静态 HTML」，自建预渲染脚本约几十行即可覆盖。</p>\n<h2 id="user-content-构建链路">构建链路</h2>\n<p>示例内容：流程分四步——校验、客户端构建、SSR 构建、预渲染。</p>\n<h3 id="user-content-内容校验">内容校验</h3>\n<p>示例内容：front-matter 用 Zod 校验，任何字段缺失都会中断构建并指出文件路径。</p>\n<h3 id="user-content-代码高亮">代码高亮</h3>\n<p>示例内容：Shiki 只在构建期运行，产物是带内联样式的浅色 HTML。</p>\n<div class="codeBlock"><button class="codeCopy" type="button" aria-label="复制代码">复制</button><pre class="shiki github-light" style="background-color:#fff;color:#24292e" tabindex="0"><code><span class="line"><span style="color:#6A737D">// 示例代码</span></span>\n<span class="line"><span style="color:#D73A49">export</span><span style="color:#D73A49"> function</span><span style="color:#6F42C1"> Hello</span><span style="color:#24292E">({ </span><span style="color:#E36209">name</span><span style="color:#24292E"> }</span><span style="color:#D73A49">:</span><span style="color:#24292E"> { </span><span style="color:#E36209">name</span><span style="color:#D73A49">:</span><span style="color:#005CC5"> string</span><span style="color:#24292E"> }) {</span></span>\n<span class="line"><span style="color:#D73A49">  return</span><span style="color:#24292E"> &#x3C;</span><span style="color:#22863A">h1</span><span style="color:#24292E">>你好，{name}&#x3C;/</span><span style="color:#22863A">h1</span><span style="color:#24292E">>;</span></span>\n<span class="line"><span style="color:#24292E">}</span></span></code></pre></div>\n<h2 id="user-content-关键参数对比">关键参数对比</h2>\n<table>\n<thead>\n<tr>\n<th>项</th>\n<th>取值</th>\n<th>说明</th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<td>首屏 JS 预算</td>\n<td>100KB</td>\n<td>gzip 后</td>\n</tr>\n<tr>\n<td>正文宽度</td>\n<td>约 720px</td>\n<td>68 字符</td>\n</tr>\n<tr>\n<td>断点</td>\n<td>640 / 1024 / 1440</td>\n<td>三档</td>\n</tr>\n</tbody>\n</table>\n<h2 id="user-content-后续计划">后续计划</h2>\n<p>示例内容：接入 Lighthouse CI，把性能预算变成自动化门禁。</p>', "headings": [{ "depth": 2, "text": "为什么不用现成框架", "id": "为什么不用现成框架" }, { "depth": 2, "text": "构建链路", "id": "构建链路" }, { "depth": 3, "text": "内容校验", "id": "内容校验" }, { "depth": 3, "text": "代码高亮", "id": "代码高亮" }, { "depth": 2, "text": "关键参数对比", "id": "关键参数对比" }, { "depth": 2, "text": "后续计划", "id": "后续计划" }] }, "prerender-pitfalls": { "bodyHtml": '<blockquote>\n<p>本文是示例内容，用于演示「无摘要时自动截取正文」的列表样式。</p>\n</blockquote>\n<h2 id="user-content-渲染期访问浏览器-api">渲染期访问浏览器 API</h2>\n<p>示例内容：预渲染在 Node 中执行，任何 <code>window</code>、<code>document</code> 访问都会抛错，必须放进 <code>useEffect</code>。</p>\n<h2 id="user-content-hydration-不一致">Hydration 不一致</h2>\n<p>示例内容：<code>new Date()</code>、<code>Math.random()</code> 这类不确定值会让两端渲染结果不同，应改成构建期常量。</p>\n<h2 id="user-content-路由表分散">路由表分散</h2>\n<p>示例内容：客户端与预渲染必须共用同一份路由定义，否则线上直接访问子路径会 404。</p>', "headings": [{ "depth": 2, "text": "渲染期访问浏览器 API", "id": "渲染期访问浏览器-api" }, { "depth": 2, "text": "Hydration 不一致", "id": "hydration-不一致" }, { "depth": 2, "text": "路由表分散", "id": "路由表分散" }] }, "cache-debug-notes": { "bodyHtml": '<blockquote>\n<p>本文是示例内容，用于演示跨年分组（2025 年）。</p>\n</blockquote>\n<h2 id="user-content-现象">现象</h2>\n<p>示例内容：CI 缓存命中率突然归零，构建耗时翻倍。</p>\n<h2 id="user-content-定位过程">定位过程</h2>\n<p>示例内容：先对比两次构建的 cache key，再检查 lock 文件是否有非预期变更。</p>\n<div class="codeBlock"><button class="codeCopy" type="button" aria-label="复制代码">复制</button><pre class="shiki github-light" style="background-color:#fff;color:#24292e" tabindex="0"><code><span class="line"><span style="color:#6A737D"># 示例命令</span></span>\n<span class="line"><span style="color:#6F42C1">git</span><span style="color:#032F62"> diff</span><span style="color:#032F62"> HEAD~1</span><span style="color:#005CC5"> --</span><span style="color:#032F62"> package-lock.json</span></span></code></pre></div>\n<h2 id="user-content-结论">结论</h2>\n<p>示例内容：一次依赖升级改写了 lock 文件格式，导致 key 计算结果变化。固定 key 的组成后恢复。</p>', "headings": [{ "depth": 2, "text": "现象", "id": "现象" }, { "depth": 2, "text": "定位过程", "id": "定位过程" }, { "depth": 2, "text": "结论", "id": "结论" }] } } };
const bodies = rawBodies;
function getProjectBody(slug) {
  return bodies.projects[slug];
}
function getPostBody(slug) {
  return bodies.posts[slug];
}
export {
  MarkdownBody as M,
  getPostBody as a,
  getProjectBody as g
};
