/**
 * 站点配置（单例）。以下为占位示例值，站主上线前替换为真实信息。
 */
import { siteConfigSchema, type SiteConfig } from '../lib/schema';

export const site: SiteConfig = siteConfigSchema.parse({
  name: '张示例',
  role: '前端工程师',
  tagline: '做前端基础设施的工程师',
  location: '上海',
  availability: '在职，考虑机会',
  email: 'hello@example.com',
  resumeUrl: '/resume-2026-10.pdf',
  social: [
    { label: 'GitHub', href: 'https://github.com/example' },
    { label: '掘金', href: 'https://juejin.cn/user/example' },
  ],
});

export interface Experience {
  company: string;
  title: string;
  period: string;
  current: boolean;
  outcome: string;
}

/** 经历时间线（示例占位数据，按时间倒序，进行中的排最前） */
export const experiences: Experience[] = [
  {
    company: '示例科技有限公司',
    title: '高级前端工程师',
    period: '2023.06 – 至今',
    current: true,
    outcome: '主导前端基础设施升级，构建耗时降低 60%。',
  },
  {
    company: '示例网络公司',
    title: '前端工程师',
    period: '2020.07 – 2023.05',
    current: false,
    outcome: '负责核心业务前端，支撑日活百万级页面。',
  },
];

export interface Education {
  school: string;
  major: string;
  period: string;
}

export const education: Education[] = [
  {
    school: '示例大学',
    major: '计算机科学与技术 · 本科',
    period: '2016 – 2020',
  },
];

/** 「当前在做什么」段落（示例） */
export const currentFocus: string[] = [
  '在维护本站点，并把工作中的工程实践整理成文章。',
  '关注构建性能与 Web 无障碍方向。',
];
