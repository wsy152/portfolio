import { jsxs, jsx } from "react/jsx-runtime";
import { useParams, Navigate, Link } from "react-router-dom";
import { b as findPost, c as postPrevNext, d as allPosts, A as ArrowLeftIcon, s as site } from "../entry-server.js";
import { a as getPostBody, M as MarkdownBody } from "./store-bodies-CzwW5kKy.js";
import "node:stream";
import "react-dom/server";
import "react-router-dom/server.mjs";
import "react";
import "zod";
const toc = "_toc_11ol4_1";
const title$1 = "_title_11ol4_9";
const item = "_item_11ol4_16";
const depth3 = "_depth3_11ol4_28";
const styles$2 = {
  toc,
  title: title$1,
  item,
  depth3
};
function TableOfContents({ headings }) {
  if (headings.length < 3) {
    return null;
  }
  return /* @__PURE__ */ jsxs("nav", { className: styles$2.toc, "aria-label": "文章目录", children: [
    /* @__PURE__ */ jsx("h2", { className: styles$2.title, children: "目录" }),
    /* @__PURE__ */ jsx("ul", { children: headings.map((heading) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
      "a",
      {
        href: `#${heading.id}`,
        className: `${styles$2.item} ${heading.depth === 3 ? styles$2.depth3 : ""}`,
        children: heading.text
      }
    ) }, heading.id)) })
  ] });
}
const wrapper = "_wrapper_42a4s_1";
const columns = "_columns_42a4s_5";
const styles$1 = {
  wrapper,
  columns
};
function ArticleLayout({ headings, children }) {
  return /* @__PURE__ */ jsx("div", { className: `container ${styles$1.wrapper}`, children: /* @__PURE__ */ jsxs("div", { className: styles$1.columns, children: [
    /* @__PURE__ */ jsx("div", { children }),
    /* @__PURE__ */ jsx(TableOfContents, { headings })
  ] }) });
}
const head = "_head_5i8re_1";
const back = "_back_5i8re_5";
const title = "_title_5i8re_14";
const meta = "_meta_5i8re_20";
const author = "_author_5i8re_28";
const authorAvatar = "_authorAvatar_5i8re_38";
const authorName = "_authorName_5i8re_52";
const authorBio = "_authorBio_5i8re_57";
const prevNext = "_prevNext_5i8re_63";
const styles = {
  head,
  back,
  title,
  meta,
  author,
  authorAvatar,
  authorName,
  authorBio,
  prevNext
};
function BlogDetailPage() {
  const { slug } = useParams();
  const post = slug ? findPost(allPosts, slug) : void 0;
  const body = post ? getPostBody(post.slug) : void 0;
  if (!post || !body) {
    return /* @__PURE__ */ jsx(Navigate, { to: "/404", replace: true });
  }
  const { prev, next } = postPrevNext(allPosts, post.slug);
  return /* @__PURE__ */ jsxs(ArticleLayout, { headings: body.headings, children: [
    /* @__PURE__ */ jsxs("header", { className: styles.head, children: [
      /* @__PURE__ */ jsxs(Link, { to: "/blog", className: styles.back, children: [
        /* @__PURE__ */ jsx(ArrowLeftIcon, {}),
        " 返回博客"
      ] }),
      /* @__PURE__ */ jsx("h1", { className: styles.title, children: post.title }),
      /* @__PURE__ */ jsxs("div", { className: styles.meta, children: [
        /* @__PURE__ */ jsx("time", { dateTime: post.date, children: post.displayDate }),
        /* @__PURE__ */ jsxs("span", { children: [
          "约 ",
          post.readingMinutes,
          " 分钟"
        ] }),
        post.tags.map((tag) => /* @__PURE__ */ jsxs("span", { children: [
          "#",
          tag
        ] }, tag))
      ] })
    ] }),
    /* @__PURE__ */ jsx(MarkdownBody, { html: body.bodyHtml }),
    /* @__PURE__ */ jsxs("div", { className: styles.author, children: [
      /* @__PURE__ */ jsx("div", { className: styles.authorAvatar, "aria-hidden": "true", children: site.name.slice(0, 1) }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx("p", { className: styles.authorName, children: site.name }),
        /* @__PURE__ */ jsx("p", { className: styles.authorBio, children: site.tagline })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("nav", { className: styles.prevNext, "aria-label": "文章导航", children: [
      /* @__PURE__ */ jsx("span", { children: prev && /* @__PURE__ */ jsxs(Link, { to: prev.href, children: [
        "← ",
        prev.title
      ] }) }),
      /* @__PURE__ */ jsx("span", { children: next && /* @__PURE__ */ jsxs(Link, { to: next.href, children: [
        next.title,
        " →"
      ] }) })
    ] })
  ] });
}
export {
  BlogDetailPage as default
};
