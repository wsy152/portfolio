---
title: 示例 · 构建缓存优化
slug: build-cache
summary: 示例项目：把 CI 构建时间从 18 分钟降到 4 分钟的缓存分层实践。
role: 独立负责
startDate: 2026-01-15
stack: [Vite, GitHub Actions]
overview:
  problem: 示例内容：CI 全量构建每次 18 分钟，前端迭代被构建队列阻塞。
  goal: 示例内容：通过依赖缓存与产物分层，把常规提交构建控制在 5 分钟内。
  result: 示例内容：常规构建降至 4 分钟，团队反馈迭代节奏明显改善（数据为脱敏示例）。
featured: false
order: 3
draft: false
---

> 本文是示例内容。该项目未设置结束时间，用于演示「进行中」的排序规则。

## 背景与挑战

示例内容：monorepo 下任何改动都触发全量构建。

## 方案与取舍

示例内容：按「依赖层 / 类型层 / 产物层」分层缓存，取舍是缓存命中率的观测成本。

```yaml
# 示例代码：缓存 key 分层
- uses: actions/cache@v4
  with:
    path: node_modules
    key: deps-${{ hashFiles('**/package-lock.json') }}
```

## 结果与反思

示例内容：构建时间达标。反思：缓存失效策略需要与分支模型一起设计。
