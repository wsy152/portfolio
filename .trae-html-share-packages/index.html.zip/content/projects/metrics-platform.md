---
title: 示例 · 指标监控平台
slug: metrics-platform
summary: 示例项目：把 12 个分散的监控页面收拢成一个可下钻的统一工作台。
role: 前端负责人
teamSize: 6
startDate: 2025-03-01
endDate: 2025-11-30
stack: [React, TypeScript, WebSocket]
links:
  - label: 在线演示
    href: https://example.com
    kind: live
overview:
  problem: 示例内容：业务方需要跨 12 个页面手工对比指标，一次排障要在多个页面间反复切换。
  goal: 示例内容：在一个页面内完成指标聚合、下钻与告警确认，减少页面切换。
  result: 示例内容：上线后排障流程收拢到单页面完成，切换次数显著下降（数据为脱敏示例）。
featured: true
order: 1
draft: false
---

> 本文是示例内容，用于演示项目详情的版式，所有数据均为占位。

## 背景与挑战

示例内容：监控能力分散在 12 个独立页面，排障时需要人工在页面之间对照数据。挑战在于信息架构需要重新设计，同时保持与既有告警系统的兼容。

## 方案与取舍

示例内容：采用单页工作台方案，以路由级下钻代替页面跳转。取舍点在于首屏数据量上升，通过按面板懒加载与 WebSocket 增量推送控制。

```ts
// 示例代码：面板按需订阅
function usePanelSubscription(panelId: string) {
  useEffect(() => {
    const channel = openChannel(`panel:${panelId}`);
    return () => channel.close();
  }, [panelId]);
}
```

## 关键决策

示例内容：告警确认动作收拢到统一队列，避免多入口状态不一致。

## 结果与反思

示例内容：排障路径明显缩短。反思：早期低估了告警状态机的复杂度，应在原型期引入真实排障演练。
