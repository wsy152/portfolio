---
title: 示例 · 组件设计系统
slug: design-system
summary: 示例项目：为三条业务线统一组件与设计 token，减少重复实现。
role: 核心贡献者
teamSize: 4
startDate: 2024-05-01
endDate: 2025-02-28
stack: [React, CSS, Figma]
links:
  - label: 源码
    href: https://github.com/example/design-system
    kind: repo
overview:
  problem: 示例内容：三条业务线各自维护组件，同一按钮有五种实现，视觉与交互不一致。
  goal: 示例内容：建立统一 token 与组件库，让新页面默认走设计系统。
  result: 示例内容：组件库覆盖主要业务场景，重复实现基本消除（数据为脱敏示例）。
featured: true
order: 2
draft: false
---

> 本文是示例内容，用于演示项目详情版式。

## 背景与挑战

示例内容：业务快速扩张期各团队独立实现组件，视觉走样、无障碍缺失。挑战在于迁移老页面时不能阻塞业务迭代。

## 方案与取舍

示例内容：token 先行，组件随后，采用新旧并行的迁移策略。放弃了全量重写，选择按页面流量从高到低逐步替换。

```css
/* 示例代码：token 定义 */
:root {
  --accent: #2563eb;
  --radius: 10px;
}
```

## 关键决策

示例内容：不引入第三方 UI 库，全部组件自建以保证 token 一致性。

## 结果与反思

示例内容：新需求默认基于设计系统开发。反思：文档站应该与组件库同期建设，而非事后补齐。
