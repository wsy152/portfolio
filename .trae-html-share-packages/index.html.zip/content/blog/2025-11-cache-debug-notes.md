---
title: 示例 · 一次构建缓存排查记录
slug: cache-debug-notes
date: 2025-11-20
tags: [构建]
---

> 本文是示例内容，用于演示跨年分组（2025 年）。

## 现象

示例内容：CI 缓存命中率突然归零，构建耗时翻倍。

## 定位过程

示例内容：先对比两次构建的 cache key，再检查 lock 文件是否有非预期变更。

```bash
# 示例命令
git diff HEAD~1 -- package-lock.json
```

## 结论

示例内容：一次依赖升级改写了 lock 文件格式，导致 key 计算结果变化。固定 key 的组成后恢复。
