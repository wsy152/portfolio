---
title: 示例 · 草稿项目
slug: draft-example
summary: 示例草稿：这篇内容不会出现在列表与线上产物中。
role: 示例
startDate: 2026-06-01
stack: [React]
overview:
  problem: 示例内容：这是草稿，仅本地预览可见，不进入线上产物。
  goal: 示例内容：验证草稿过滤逻辑。
  result: 示例内容：构建产物中不应出现该页面。
draft: true
---

示例草稿正文，不进入列表、不生成页面、不进入站点地图。
